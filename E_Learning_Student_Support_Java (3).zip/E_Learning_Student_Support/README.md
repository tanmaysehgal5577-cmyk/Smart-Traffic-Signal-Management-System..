# E-Learning Student Support

A Java 21 + Spring Boot student-support portal with a dashboard, notice board, assignment tracker, attendance tracker, and curated study links.

## Requirements
- JDK 21
- Maven 3.9+
- IntelliJ IDEA or VS Code (Java extensions)

## Run on Windows
1. Extract the ZIP.
2. Open the `E_Learning_Student_Support` folder in VS Code or IntelliJ.
3. Open a terminal in the project folder.
4. Run:

```bash
mvn spring-boot:run
```

5. Open http://localhost:8080

Maven downloads the required dependencies on the first run. The app uses a local file-based H2 database by default, so MySQL installation is not required for this starter.

## Database
- H2 file database: `./data/student_support_db`
- H2 console: http://localhost:8080/h2-console
- JDBC URL: `jdbc:h2:file:./data/student_support_db`
- Username: `sa`
- Password: (blank)

## Main routes
- `/` dashboard
- `/notices` create and view notices
- `/assignments` create and view assignments
- `/attendance` view and record attendance
- `/resources` study links

## Important scope note
This is a runnable academic starter implementation. It does not yet include real student accounts/login, role permissions, assignment file submissions, timetable scheduling, push notifications, or production-grade authorization. The attendance and notice forms are open demo forms; add authentication and role-based access before deploying publicly.

## Switch to MySQL (optional)
Add the MySQL driver to `pom.xml` and replace the datasource properties with your MySQL URL, username and password. Keep credentials outside source control.
