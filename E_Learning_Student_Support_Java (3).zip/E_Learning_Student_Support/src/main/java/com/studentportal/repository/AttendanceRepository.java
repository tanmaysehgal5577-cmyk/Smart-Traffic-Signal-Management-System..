package com.studentportal.repository;
import com.studentportal.model.AttendanceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface AttendanceRepository extends JpaRepository<AttendanceRecord, Long> {
    List<AttendanceRecord> findByStudentNameIgnoreCaseOrderByAttendanceDateDesc(String studentName);
}
