package com.studentportal.config;

import com.studentportal.model.*;
import com.studentportal.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.time.LocalDate;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner seed(NoticeRepository notices, AssignmentRepository assignments, AttendanceRepository attendance) {
        return args -> {
            if (notices.count() == 0) {
                notices.save(new Notice("Welcome to Student Support", "Use this portal to check notices, assignments, attendance and study resources."));
                notices.save(new Notice("Library Hours", "The central library is open from 9:00 AM to 6:00 PM on working days."));
            }
            if (assignments.count() == 0) {
                assignments.save(new Assignment("Java Programming", "OOP Concepts", "Prepare notes and examples on inheritance, polymorphism and encapsulation.", LocalDate.now().plusDays(7)));
                assignments.save(new Assignment("Database Management", "SQL Queries", "Write SELECT, JOIN, GROUP BY and aggregate queries.", LocalDate.now().plusDays(10)));
            }
            if (attendance.count() == 0) {
                attendance.save(new AttendanceRecord("Demo Student", "Java Programming", LocalDate.now().minusDays(2), true));
                attendance.save(new AttendanceRecord("Demo Student", "Database Management", LocalDate.now().minusDays(1), true));
                attendance.save(new AttendanceRecord("Demo Student", "Mathematics", LocalDate.now(), false));
            }
        };
    }
}
