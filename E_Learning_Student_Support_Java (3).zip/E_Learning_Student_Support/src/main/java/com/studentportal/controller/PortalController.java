package com.studentportal.controller;

import com.studentportal.model.*;
import com.studentportal.repository.*;
import jakarta.validation.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;

@Controller
public class PortalController {
    private final NoticeRepository notices;
    private final AssignmentRepository assignments;
    private final AttendanceRepository attendance;

    public PortalController(NoticeRepository notices, AssignmentRepository assignments, AttendanceRepository attendance) {
        this.notices = notices; this.assignments = assignments; this.attendance = attendance;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("noticeCount", notices.count());
        model.addAttribute("assignmentCount", assignments.count());
        model.addAttribute("notices", notices.findAll());
        model.addAttribute("assignments", assignments.findAllByOrderByDueDateAsc());
        return "index";
    }

    @GetMapping("/notices")
    public String noticePage(Model model) { model.addAttribute("notices", notices.findAll()); return "notices"; }

    @PostMapping("/notices")
    public String addNotice(@RequestParam @NotBlank String title, @RequestParam @NotBlank String message) {
        notices.save(new Notice(title.trim(), message.trim()));
        return "redirect:/notices";
    }

    @GetMapping("/assignments")
    public String assignmentPage(Model model) {
        model.addAttribute("assignments", assignments.findAllByOrderByDueDateAsc());
        return "assignments";
    }

    @PostMapping("/assignments")
    public String addAssignment(@RequestParam String subject, @RequestParam String title,
            @RequestParam String description, @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dueDate) {
        assignments.save(new Assignment(subject.trim(), title.trim(), description.trim(), dueDate));
        return "redirect:/assignments";
    }

    @GetMapping("/attendance")
    public String attendancePage(@RequestParam(defaultValue = "Demo Student") String student, Model model) {
        var records = attendance.findByStudentNameIgnoreCaseOrderByAttendanceDateDesc(student);
        long total = records.size();
        long present = records.stream().filter(AttendanceRecord::isPresent).count();
        double percentage = total == 0 ? 0 : (present * 100.0 / total);
        model.addAttribute("records", records);
        model.addAttribute("student", student);
        model.addAttribute("percentage", String.format("%.1f", percentage));
        return "attendance";
    }

    @PostMapping("/attendance")
    public String markAttendance(@RequestParam String studentName, @RequestParam String subject,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(defaultValue = "false") boolean present) {
        attendance.save(new AttendanceRecord(studentName.trim(), subject.trim(), date, present));
        return "redirect:/attendance?student=" + java.net.URLEncoder.encode(studentName, java.nio.charset.StandardCharsets.UTF_8);
    }

    @GetMapping("/resources")
    public String resources() { return "resources"; }
}
