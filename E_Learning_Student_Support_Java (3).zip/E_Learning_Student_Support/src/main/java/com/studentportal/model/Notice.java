package com.studentportal.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Notice {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    @Column(length = 2000) private String message;
    private LocalDateTime postedAt = LocalDateTime.now();

    public Notice() {}
    public Notice(String title, String message) { this.title = title; this.message = message; }
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public String getMessage() { return message; }
    public LocalDateTime getPostedAt() { return postedAt; }
    public void setTitle(String title) { this.title = title; }
    public void setMessage(String message) { this.message = message; }
}
