package com.studentportal.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class AttendanceRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String studentName;
    private String subject;
    private LocalDate attendanceDate;
    private boolean present;

    public AttendanceRecord() {}
    public AttendanceRecord(String studentName, String subject, LocalDate date, boolean present) {
        this.studentName = studentName; this.subject = subject; this.attendanceDate = date; this.present = present;
    }
    public Long getId() { return id; }
    public String getStudentName() { return studentName; }
    public String getSubject() { return subject; }
    public LocalDate getAttendanceDate() { return attendanceDate; }
    public boolean isPresent() { return present; }
}
