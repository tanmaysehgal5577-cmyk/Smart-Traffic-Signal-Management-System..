@echo off
echo Starting E-Learning Student Support...
call mvn spring-boot:run
pause
